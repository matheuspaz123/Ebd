package com.example.ebd.data.model

data class User (var usuario: String, var senha: String)